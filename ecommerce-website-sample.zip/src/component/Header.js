import "../App.css";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
const Header = () => {
  const cartItem = useSelector((state) => state.cart);
  return (
    <div className="navigation">
      <div className="header_logo">
        <h1>my-App</h1>
      </div>
      <div className="header_menu">
        <span>
          <Link to="/">Home</Link>
        </span>
        <span>
          <Link to="/about">About us</Link>
        </span>
        <span>
          <Link to="/contact">Contact us</Link>
        </span>
      </div>
      <div className="header_cart">
        <Link to="/cart">
          <div className="cart_logo">
            <span>{cartItem.length}</span>
            <img
              src="https://e7.pngegg.com/pngimages/833/426/png-clipart-shopping-cart-shopping-cart.png"
              alt=""
            />
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Header;
