import { useDispatch, useSelector } from "react-redux";
import { removeFromCart } from "../../redux/action";
import "../../App.css";

const Cart = () => {
  const dispatch = useDispatch();
  const cartItem = useSelector((state) => state.cart);
  const totalAmount = cartItem.reduce((acc, el) => (acc += el.price), 0);

  const OnOrder = () => {
    let value = confirm("Are You Sure");
    if (value === true) {
      alert("your order is placed !!!");
    } else {
      alert("Please Order again !!");
    }
  };

  return (
    <div className="cart_container">
      <div className="cart_box">
        {cartItem.length !== 0 ? (
          <table className="cart_table">
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Manage Cart</th>
            </tr>
            {cartItem.map((el) => (
              <tr key={Math.random().toString()} className="cart_product_item">
                <td>
                  <img src={el.image} alt="" />
                </td>
                <td>{el.title.slice(0, 15)}</td>
                <td>{el.category}</td>
                <td>{el.price}</td>
                <td className="remove_item">
                  <button onClick={() => dispatch(removeFromCart(el))}>
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </table>
        ) : (
          <h2>Your cart is empty</h2>
        )}
        <div className="order_section">
          <div className="amount">
            <span>Amount:-</span>
            <span>{totalAmount}</span>
          </div>
          <div className="discount">
            <span>discount:-</span>
            <span>{(totalAmount / 10).toFixed(2)}</span>
          </div>
          <div className="tax">
            <span>tax:-</span>
            <span>0.00</span>
          </div>
          <div className="total">
            <span>Total</span>
            <span>{(totalAmount - totalAmount / 10).toFixed(2)}</span>
          </div>
          <div className="order">
            <button onClick={() => OnOrder()}>Order Now</button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Cart;
