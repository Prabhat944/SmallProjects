import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "../redux/action";
import "../App.css";
const Content = () => {
  const dispatch = useDispatch();
  const items = useSelector((state) => state.store);

  return (
    <div className="product_list">
      {items.map((el) => (
        <ul className="product" key={el.id}>
          <li>
            <img src={el.image} alt="" />
          </li>
          <li className="title">{el.title.slice(0, 17)}</li>
          <li className="price">${el.price}</li>
          <li>
            <button onClick={() => dispatch(addToCart(el))}>Add to Cart</button>
          </li>
        </ul>
      ))}
    </div>
  );
};
export default Content;
