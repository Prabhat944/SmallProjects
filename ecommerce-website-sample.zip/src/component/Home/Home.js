import Content from "../Content";

const Home = () => {
  return (
    <div style={{ textAlign: "center" }}>
      <h2>Welcome to Your Favourite Store</h2>

      <Content />
    </div>
  );
};
export default Home;
