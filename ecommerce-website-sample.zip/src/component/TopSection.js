import { useDispatch } from "react-redux";

const TopSection = () => {
  const dispatch = useDispatch();
  return (
    <div style={{ display: "flex", gap: "20px" }}>
      <button onClick={() => dispatch({ type: "Increase", payload: 5 })}>
        Button A
      </button>
      <button onClick={() => dispatch({ type: "Decrease", payload: 5 })}>
        Button B
      </button>
      <button onClick={() => dispatch({ type: "INCREASE", payload: 5 })}>
        Button C
      </button>
    </div>
  );
};
export default TopSection;
