import { combineReducers } from "redux";
import { cartReducer } from "./cartReducer";
import { storeReducer } from "./reducer";

export default combineReducers({ cart: cartReducer, store: storeReducer });
