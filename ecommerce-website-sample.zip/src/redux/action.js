import {
  UPDATE_STORE,
  UPDATE_CART,
  ADD_TO_CART,
  REMOVE_FROM_CART
} from "./constant";

export const addToCart = (data) => {
  return {
    type: ADD_TO_CART,
    payload: data
  };
};

export const removeFromCart = (data) => {
  return {
    type: REMOVE_FROM_CART,
    payload: data
  };
};

export const updateCart = (data) => {
  return {
    type: UPDATE_CART,
    payload: data
  };
};

export const updateStore = (data) => {
  return {
    type: UPDATE_STORE,
    payload: data
  };
};
