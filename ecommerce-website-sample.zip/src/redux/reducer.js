import { UPDATE_THE_STORE } from "./constant";

export const storeReducer = (store = [], action) => {
  switch (action.type) {
    case UPDATE_THE_STORE:
      console.log(action.payload);
      return [...action.payload];
    default:
      return store;
  }
};
