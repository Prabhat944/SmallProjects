import {
  UPDATE_CART,
  UPDATE_THE_CART,
  ADD_TO_CART,
  REMOVE_FROM_CART
} from "./constant";

export const cartReducer = (cart = [], action) => {
  switch (action.type) {
    // case UPDATE_CART:
    //   return { ...action.payload };
    case UPDATE_THE_CART:
      return [...action.payload];
    case ADD_TO_CART:
      return [...cart, action.payload];
    case REMOVE_FROM_CART:
      const remaining = cart.filter((el) => el.id !== action.payload.id);
      return [...remaining];
    default:
      return cart;
  }
};
