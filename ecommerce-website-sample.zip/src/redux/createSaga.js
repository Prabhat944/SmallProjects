import axios from "axios";
import { takeEvery, put } from "redux-saga/effects";
import {
  UPDATE_STORE,
  UPDATE_THE_STORE,
  UPDATE_CART,
  UPDATE_THE_CART
} from "./constant";

function* getProduct() {
  const response = yield axios
    .get("https://fakestoreapi.com/products")
    .catch((err) => console.log(err));
  yield put({ type: UPDATE_THE_STORE, payload: response.data });
}
function* getCart() {
  const response = yield axios
    .get("https://fakestoreapi.com/carts")
    .catch((err) => console.log(err));
  yield put({ type: UPDATE_THE_CART, payload: response.data });
  //  yield put({type:UPDATE_THE_STORE,payload:response.data})
}

export function* productSaga() {
  yield takeEvery(UPDATE_STORE, getProduct);
}
export function* cartSaga() {
  yield takeEvery(UPDATE_CART, getCart);
}
