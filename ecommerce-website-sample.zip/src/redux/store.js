// import { createStore } from "redux";
import { configureStore } from "@reduxjs/toolkit";
import rootReducers from "./rootReducer";
import createSagaMiddleware from "redux-saga";
import { productSaga, cartSaga } from "./createSaga";

const sagaMiddleWare = createSagaMiddleware();
const store = configureStore({
  reducer: rootReducers,
  middleware: () => [sagaMiddleWare]
});
sagaMiddleWare.run(productSaga);
sagaMiddleWare.run(cartSaga);
export default store;
