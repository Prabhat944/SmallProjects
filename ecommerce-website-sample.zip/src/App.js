import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { Route, Routes } from "react-router-dom";
import Header from "./component/Header";
import Home from "./component/Home/Home";
import Cart from "./component/Cart/Cart";
import { updateStore } from "./redux/action";

export default function App({ itemName = "prabhat" }) {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(updateStore());
    // eslint-disable-next-line
  }, []);
  return (
    <div>
      <Header />
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/cart" element={<Cart />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </div>
  );
}
